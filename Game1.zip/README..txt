Gabriel Lops
glops@uci.edu
13445192

This game is called The Falling Square. In this game I want the player to feel a sense of frustration that the game 
is endless and they'll never be able to win, but in reality there is a win state. In the game you are a square that 
starts off falling from the air your goal is to fall down 2500 feet and reach the game winning platform. The amount 
of feet you have fallen is displayed above your square; however, the player does not know the end goal is 2500 ft. On 
the way down the player must dodge platforms in order to reach the bottom. If the player touches the sides of the wall
or any platform the game will stop and you lose in which case you can hit restart or quit. If you make it to the bottom
of the endless well. The game will tell you that you have won at which point you can try again or stop playing.
Good Luck!!!